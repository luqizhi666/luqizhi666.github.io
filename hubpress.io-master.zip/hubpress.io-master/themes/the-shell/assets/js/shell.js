$(function(){
	$('pre').addClass('prettyprint');
	prettyPrint();
});